package com.demoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
