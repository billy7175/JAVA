-- execute as system

CREATE USER demoweb IDENTIFIED BY "oracle";

GRANT CONNECT, RESOURCE TO demoweb;

-- execute as demoweb

CREATE TABLE member 
(
    memberid VARCHAR2 (20) PRIMARY KEY
    , passwd VARCHAR2 (100) NOT NULL
    , email VARCHAR2 (50) NOT NULL
    , usertype VARCHAR2 (50) DEFAULT ('user') CHECK ( usertype IN ('user', 'admin'))
    , regdate DATE DEFAULT (SYSDATE)
    , active CHAR(1) DEFAULT ('1')
);

CREATE TABLE board
(
    boardno NUMBER PRIMARY KEY
    , title VARCHAR2 (100) NOT NULL
    , writer VARCHAR2 (20) NOT NULL
    , content VARCHAR2 (4000) NOT NULL
    , regdate DATE DEFAULT (SYSDATE)
    , readcount NUMBER DEFAULT (0)
    , deleted CHAR(1) DEFAULT ('0')
    , CONSTRAINT fk_board_to_member FOREIGN KEY (writer) REFERENCES member (memberid)
);

CREATE SEQUENCE board_sequence NOCACHE;

CREATE TABLE boardattach
(
    attachno NUMBER PRIMARY KEY
    , boardno NUMBER NOT NULL
    , userfilename VARCHAR2 (100) NOT NULL
    , savedfilename VARCHAR2 (100) NOT NULL
    , downloadcount NUMBER DEFAULT (0)
    , CONSTRAINT fk_boardattach_to_board FOREIGN KEY (boardno) REFERENCES board (boardno)
);

CREATE SEQUENCE boardattach_sequence NOCACHE;

CREATE TABLE boardcomment
(
    commentno NUMBER PRIMARY KEY
    , boardno NUMBER NOT NULL
    , writer VARCHAR2 (20) NOT NULL
    , content VARCHAR2 (1000) NOT NULL
    , regdate DATE DEFAULT (SYSDATE)
    , deleted CHAR(1) DEFAULT ('0')
    , groupno NUMBER NOT NULL
    , step NUMBER NOT NULL
    , depth NUMBER NOT NULL
    , CONSTRAINT fk_boardcomment_to_board FOREIGN KEY (boardno) REFERENCES board (boardno)
    , CONSTRAINT fk_boardcomment_to_member FOREIGN KEY (writer) REFERENCES member (memberid)
);

CREATE SEQUENCE boardcomment_sequence NOCACHE;

