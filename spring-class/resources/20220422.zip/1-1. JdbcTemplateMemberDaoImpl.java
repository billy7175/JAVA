1-1. JdbcTemplateMemberDaoImpl.java

	@Override
	public Member selectMemberByIdAndPasswd(Member member2) {
		StringBuilder sql = new StringBuilder(128);
		sql.append("SELECT memberid, email, regdate, usertype, active ");
		sql.append("FROM member ");
		sql.append("WHERE memberid = ? and passwd = ? and active = '1'");
		
		Member member = jdbcTemplate.queryForObject(sql.toString(), 
													new RowMapper<Member>() { // 1. RowMapper<Member> 인터페이스 구현 클래스 만들기 + 그 클래스의 인스턴스 만들기

														@Override
														public Member mapRow(ResultSet rs, int rowNum) throws SQLException {
															Member member = new Member();
															member.setMemberId(member2.getMemberId());
															member.setEmail(rs.getString(2));
															member.setRegDate(rs.getDate(3));
															member.setUserType(rs.getString(4));
															member.setActive(rs.getBoolean(5));
															return member;
														} 
			
													}, 
													member2.getMemberId(), member2.getPasswd());

		return member;
	}

1-2. AccountController.java

    @PostMapping(path = { "/login" })
	public String login(Member member, HttpSession session, Model model) {
		//1. 데이터읽기 // 전달인자를 통해 이미 데이터 수신
		//2. 요청 처리 // 서비스에 요청
		Member confirmedMember = accountService.findMemberByIdAndPasswd(member);
		if (confirmedMember != null) {
			session.setAttribute("loginuser", confirmedMember);
			return "redirect:/home";
		}
		
		//3. JSP로 데이터 전달하기 위해서 데이터 저장
		model.addAttribute("loginfail", member.getMemberId());
		
		//4. JSP 또는 다른 컨트롤러로 이동	
		return "account/login";
	}

2-1. pom.xml 파일에 의존 라이브러리 추가

		<dependency>
			<groupId>org.mybatis</groupId>
			<artifactId>mybatis</artifactId>
			<version>3.5.9</version>
		</dependency>

		<dependency>
			<groupId>org.mybatis</groupId>
			<artifactId>mybatis-spring</artifactId>
			<version>2.0.7</version>
		</dependency>

2-1. src/main/resources/ 하위에 폴더 및 파일 추가
     mybatis-config.xml
     com/demoweb/mapper/MemberMapper.xml

2-2. root-context.xml 
     mybatis bean 등록 

    <!-- 아래 bean 설정을 통해 반환되는 객체는 SqlSessionFactoryBean이 아니고 SqlSessionFactory 객체입니다. -->
	<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
		<property name="dataSource" ref="dataSource" />
		<property name="configLocation" value="classpath:mybatis-config.xml" />
	</bean>
	
	<bean id="sqlSessionTemplate" class="org.mybatis.spring.SqlSessionTemplate">
		<constructor-arg ref="sqlSessionFactory" />
	</bean>

2-2. dao 패키지에 MyBatisAccountDaoImpl 클래스 복사 + bean 등록

-------------------

3-1. MemberMapper.java 복사 ( interface )

3-2. MapperAccountServiceImpl.java 복사

3-3. 추가 구현

------------------