package com.demoweb.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.demoweb.dto.Member;

// MapperInterface - 대상 Mapper.xml 파일과 파일이름, 내부의 메서드 이름 및 전달인자가 일치하도록 구현
@Mapper
public interface MemberMapper {
	
	void insertMember(Member member);
	//Member selectMemberByIdAndPasswd(HashMap<String, Object> params);
	Member selectMemberByIdAndPasswd(Member member);

}
