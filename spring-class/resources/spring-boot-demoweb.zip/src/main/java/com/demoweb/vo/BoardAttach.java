package com.demoweb.vo;

import lombok.Data;

@Data
public class BoardAttach {
	
	private int attachNo;
	private int boardNo;
	private String userFileName;
	private String savedFileName;	

}
