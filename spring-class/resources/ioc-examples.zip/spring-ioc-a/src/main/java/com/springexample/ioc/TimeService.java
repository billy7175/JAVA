package com.springexample.ioc;

public interface TimeService {

	String getTimeString();

}